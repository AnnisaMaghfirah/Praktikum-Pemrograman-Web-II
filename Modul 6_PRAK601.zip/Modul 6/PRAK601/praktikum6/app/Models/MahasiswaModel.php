<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama = "Annisa Maghfirah";
    protected $foto = "Foto.jpg";

    public function getNama()
    {
        return $this->nama;
    }

    public function getFoto()
    {
        return $this->foto;
    }
}
