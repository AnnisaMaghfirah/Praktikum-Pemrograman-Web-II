<?php
$imageURL = "https://i.postimg.cc/ZnH2b8hy/Foto-3-4.jpg";


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Annisa Maghfirah</title>
    <style>
        img {
            max-width: 100%;
            height: 300px;
        }

        button {
            padding: 15px 25px;
            border: unset;
            border-radius: 15px;
            color: #212121;
            z-index: 1;
            background: #e8e8e8;
            position: relative;
            font-weight: 1000;
            font-size: 17px;
            -webkit-box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
            box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
            transition: all 250ms;
            overflow: hidden;
        }

        button::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 0;
            border-radius: 15px;
            background-color: #212121;
            z-index: -1;
            -webkit-box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
            box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
            transition: all 250ms
        }

        button:hover {
            color: #e8e8e8;
        }

        button:hover::before {
            width: 100%;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="card text-dark bg-white mb-3 mx-auto" style="max-width: 1000px;">
        <div class="col-md-15">
            <center>
                <img src="<?php echo $imageURL; ?>" alt="Gambar">
            </center>
        </div>
        <div class="col-md-10">
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <td>Nama Lengkap </td>
                        <td>
                            <p>: Annisa Maghfirah</p>
                        </td>
                    </tr>
                    <tr>
                        <td>NIM </td>
                        <td>
                            <p>: 2110817220002</p>
                        </td>
                    </tr>
                    <tr>
                        <td>Asal Prodi </td>
                        <td>
                            <p>: Teknologi Informasi</p>
                        </td>
                    </tr>
                    <tr>
                        <td>Hobi </td>
                        <td>
                            <p>: Travelling</p>
                        </td>
                    </tr>
                    <tr>
                        <td>Skill </td>
                        <td>
                            <p>: Photography</p>
                        </td>
                    </tr>
                    <tr>
                        <td>Motivasi Berkuliah di Prodi TI </td>
                        <td>
                            <p>: Karena Teknologi Informasi semakin berkembang pesat dan memiliki peluang karir yang menjanjikan di masa depan.</p>
                        </td>
                    </tr>
                </table>              
            </div>
        </div>
    </div>
    <form action="/">
        <div class="buttons">
            <center>
                <button>Home</button>
            </center>
        </div>
    </form>
</body>
</html>